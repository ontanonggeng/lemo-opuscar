# Intellectual-property review — BLACKSTAR v5

## Reason for retirement of v4

The owner identified the original graphic as the autograph of **Black☆Star**, a character in *Soul Eater*. The previous `brand.zip` indeed contained a traced rendition of the user's old mark. This v5 kit is wholly generated anew from independent geometric definitions and brushwork. The old autograph, stylized BLACK letters, five-point star and underlying raster are NOT included.

## Distinctiveness assessment

The new symbol is a circular interrupted annulus with a non-radial cut and a single asymmetric lime terminal, visibly distinct from the character's angular word/star signature. However, this is NOT proof of exclusivity. Similar abstract circular marks may exist elsewhere.

## Name / trademark warning

The name **BlackStar** is shared with a known anime character and potentially other active brands. In the United States, copyright normally does not protect a name or short phrase, but trademark and unfair-competition claims depend on usage and whether audiences could be confused as to the source. Indonesia likewise requires checking relevant trademarks and classes. This kit does not provide formal clearance, licensing, or legal advice.

Before promoting or monetizing a media brand under this name, independently search both the word mark and visually similar logos in the target markets and relevant services. Seek professional advice if similar marks arise.

## Useful sources

- U.S. Copyright Office: https://www.copyright.gov/help/faq/faq-protect.html
- USPTO trademark confusion analysis: https://www.uspto.gov/trademarks/search/likelihood-confusion
- USPTO comprehensive clearance: https://www.uspto.gov/trademarks/search/comprehensive-clearance-search-similar-trademarks
- Indonesian DJKI/PDKI: https://pdki-indonesia.dgip.go.id/
- Referenced character information (reference only, not incorporated into assets): https://souleater.fandom.com/wiki/Black%E2%98%86Star

## Artwork provenance

The geometric logo is defined by `source/build_blackstar_v5.py` and exported to SVG; all native raster print backgrounds are synthesized from deterministic procedural drawing and random seeds. The original `brand.zip` is excluded from this output. The included assets are newly generated and not pixel crops of previous kits.
