# BLACKSTAR — Identity Kit v5.0 / ECLIPSE CUT

Original identity system, replacing the previous anime-derived graffiti mark. The original BLACK graffiti/star signature is **not** present anywhere in the output assets or sources.

## Design language

- **Primary mark:** `Eclipse Cut`: an independently constructed broken circular band with a diagonal gap and asymmetric lime accent. Never use an anime-signature mark, a five-point interlaced star, or a handwritten `BLACK` glyph.
- **Palette:** Ink `#090C0B`; Ivory `#F5F0E4`; Signal Lime `#D7FA28`.
- **Artwork:** matte black, uneven cream paint tears, acid-lime slashes, dry-ink grain, sparse halftone. Separately painted at each requested export size by deterministic source code.
- No tagline, no extra wordmark, no CTA; no additional type on upload-ready assets. End cards: white abstract emblem on solid #000000, exactly.

## Upload-ready assets

| Use | File | Pixel size |
|---|---|---|
| Facebook Professional avatar | `facebook/profile-800.png` | 800 × 800 |
| Facebook cover | `facebook/cover-hero-1702x630.png` | 1702 × 630 |
| Facebook cover, quieter | `facebook/cover-quiet-1702x630.png` | 1702 × 630 |
| YouTube avatar | `youtube/profile-800.png` | 800 × 800 |
| YouTube banner | `youtube/banner-upload-2560x1440.jpg` | 2560 × 1440, <= 6 MB |
| YouTube video watermark | `youtube/video-watermark-150.png` | 150 × 150, transparent |
| Video ends | `video/end-card-black-9x16.png`, `video/end-card-black-16x9.png` | 1080 × 1920 and 1920 × 1080 |
| Reels, Shorts, feed, thumbnails | `facebook/`, `youtube/`, `reusable/` | Various native sizes |

`masters/` contains five scalable SVG mark variations and high-resolution transparent PNGs. `textures/` contains reusable transparent silkscreen brush assets. `source/` contains a reproducible generator script. `previews/` contains a contact sheet and YouTube central-crop preview.

## Source provenance and copyright boundary

The v4 ZIP provided by the owner was audited solely to learn the expected asset inventory and establish which material to retire; **no artwork from that archive was used to generate the new kit**. All vector vertices, compositing, digital brushes, textures, grain, and exports are created programmatically from scratch. The generator's geometry does not reproduce the Soul Eater Black☆Star autograph or star mark. Color treatment and broad grunge aesthetics are not treated as borrowed character assets.

### Legal limitations

This is a visual redesign, **not a legal clearance opinion**. Original geometry does not guarantee a unique or registrable trademark. `BlackStar` overlaps the name of a Soul Eater character and may overlap other marks; the name needs independent search in relevant countries and service classes, plus consideration of unregistered uses. Search Indonesian DJKI/PDKI and US USPTO (for US-facing media) before monetization/registration; qualified counsel can assess relevant risks. Do not imply endorsement, licensing, or association with Soul Eater.

## Production usage

- Maintain one recognizable mark across Facebook, YouTube, film outros, and overlays.
- Apply the clean mark at display sizes; textured marks risk disappearing when downscaled.
- A banner may show decorative grunge, but upload banners must retain center-safe logo placement. Assess actual device crop in platform preview.
- Keep episode titles and topical art out of the global brand templates. Add them separately for each episode.
- Do not reintroduce the previous graffiti mark into new assets.

## Generation and QA

`python source/build_blackstar_v5.py <desired-output-folder>`
Dependencies: Pillow, NumPy, Shapely, CairoSVG. Exports are painted on each native target canvas without cropping or upscaling the previous brand kit. Random seeds make the graphic generation deterministic. See `guides/QA.json` for static file checks; actual Facebook/YouTube upload and third-party trademark clearance have not been performed.
